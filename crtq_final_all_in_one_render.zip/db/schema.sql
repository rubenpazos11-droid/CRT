CREATE TABLE IF NOT EXISTS signals (
  id BIGSERIAL PRIMARY KEY,
  pair TEXT NOT NULL,
  ts TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  prob NUMERIC,
  readiness NUMERIC,
  price NUMERIC,
  context JSONB,
  outcome NUMERIC,
  status TEXT,
  report_url TEXT,
  macro_snapshot JSONB
);
CREATE INDEX IF NOT EXISTS ix_signals_pair ON signals(pair);
CREATE INDEX IF NOT EXISTS ix_signals_ts   ON signals(ts DESC);
CREATE OR REPLACE VIEW v_pair_performance AS
SELECT pair, COUNT(*) AS trades, SUM(outcome) AS pnl_r,
AVG(CASE WHEN outcome>0 THEN 1 ELSE 0 END) AS win_rate,
PERCENTILE_DISC(0.5) WITHIN GROUP (ORDER BY outcome) AS med_outcome,
AVG(outcome) AS avg_r
FROM signals GROUP BY pair ORDER BY pnl_r DESC;
CREATE OR REPLACE VIEW v_pair_equity AS
SELECT pair, ts::date AS d,
SUM(outcome) OVER (PARTITION BY pair ORDER BY ts ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cum_r
FROM signals ORDER BY pair, d;
