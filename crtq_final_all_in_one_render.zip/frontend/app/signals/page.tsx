"use client";
import React, { useEffect, useState } from 'react';
const API = process.env.NEXT_PUBLIC_CRTQ_API || 'http://localhost:8000';
type RankRow = { pair:string; trades:number; pnl_r:number; win_rate:number; med_outcome:number; avg_r:number };
type EquityPoint = { d:string; cum_r:number };
type Item = { id:number; pair:string; ts:string; prob?:number; readiness?:number; price?:number; outcome?:number; status?:string; report_url?:string };
export default function SignalsPage(){
  const [rank,setRank] = useState<RankRow[]>([]);
  const [eq,setEq] = useState<Record<string,EquityPoint[]>>({});
  const [items,setItems] = useState<Item[]>([]);
  const [auth,setAuth] = useState<string>('');
  const [busy,setBusy]=useState(false);
  async function load(){
    if(!auth){ alert('Introduce X-Auth-Token para cargar.'); return; }
    setBusy(true);
    const headers = { 'X-Auth-Token': auth } as any;
    const r1 = await fetch(`${API}/signals/ranking`, { headers });
    const j1 = await r1.json(); setRank(j1.pairs || []);
    const topPairs = (j1.pairs || []).slice(0,5).map((x:RankRow)=>x.pair).join(',');
    const r2 = await fetch(`${API}/signals/equity?pairs=${encodeURIComponent(topPairs)}`, { headers });
    const j2 = await r2.json(); setEq(j2.equities || {});
    const r3 = await fetch(`${API}/signals`, { headers });
    const j3 = await r3.json(); setItems(j3.items || []);
    setBusy(false);
  }
  function exportCSVClient(){
    const cols = ['id','pair','ts','prob','readiness','price','outcome','status','report_url'];
    const lines = [cols.join(',')].concat(items.map(it => cols.map(c => (it as any)[c] ?? '').join(',')));
    const blob = new Blob([lines.join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'signals_export.csv'; a.click(); URL.revokeObjectURL(url);
  }
  return (
    <main style={{padding:24}}>
      <h1 style={{fontSize:22,fontWeight:700}}>Historial CRT‑Q — Ranking + Export</h1>
      <div style={{display:'flex', gap:8, alignItems:'center'}}>
        <input placeholder='X-Auth-Token' value={auth} onChange={e=>setAuth(e.target.value)} style={{padding:8,border:'1px solid #ddd',borderRadius:8,width:260}} />
        <button onClick={load} style={{padding:'8px 12px', borderRadius:8, background:'#000', color:'#fff'}}>Cargar</button>
        <button onClick={exportCSVClient} style={{padding:'8px 12px', borderRadius:8, border:'1px solid #000', background:'#fff'}}>Exportar CSV</button>
      </div>
      <section style={{marginTop:16}}>
        <h2 style={{fontWeight:700}}>Ranking por P&L (R)</h2>
        <div style={{overflowX:'auto', marginTop:8}}>
          <table style={{borderCollapse:'collapse', width:'100%'}}>
            <thead><tr><th style={th}>#</th><th style={th}>Pair</th><th style={th}>Trades</th><th style={th}>P&L (R)</th><th style={th}>Win%</th><th style={th}>Med R</th><th style={th}>Avg R</th></tr></thead>
            <tbody>
              {rank.map((r, i) => (
                <tr key={r.pair} style={{borderTop:'1px solid #eee'}}>
                  <td style={td}>{i+1}</td>
                  <td style={{...td,fontWeight:600}}>{r.pair}</td>
                  <td style={td}>{r.trades}</td>
                  <td style={td}>{r.pnl_r.toFixed(2)}</td>
                  <td style={td}>{(r.win_rate*100).toFixed(1)}%</td>
                  <td style={td}>{r.med_outcome.toFixed(2)}</td>
                  <td style={td}>{r.avg_r.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <section style={{marginTop:24}}>
        <h2 style={{fontWeight:700}}>Señales recientes</h2>
        <div style={{overflowX:'auto'}}>
          <table style={{borderCollapse:'collapse', width:'100%'}}>
            <thead><tr><th style={th}>ID</th><th style={th}>Par</th><th style={th}>Fecha</th><th style={th}>Prob</th><th style={th}>Ready</th><th style={th}>Outcome</th><th style={th}>Estado</th><th style={th}>Acciones</th></tr></thead>
            <tbody>
              {items.map((it) => (
                <tr key={it.id} style={{borderTop:'1px solid #eee'}}>
                  <td style={td}>{it.id}</td>
                  <td style={td}>{it.pair}</td>
                  <td style={td}>{new Date(it.ts).toLocaleString()}</td>
                  <td style={td}>{typeof it.prob === 'number' ? it.prob.toFixed(2) : ''}</td>
                  <td style={td}>{it.readiness}</td>
                  <td style={td}>{typeof it.outcome === 'number' ? it.outcome.toFixed(2) : ''}</td>
                  <td style={td}>{it.status}</td>
                  <td style={td}><a href={`/signals/${it.id}`}>Ver / Cerrar</a></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      {busy && <div style={{marginTop:12, fontSize:12, color:'#777'}}>Cargando…</div>}
    </main>
  );
}
const th: React.CSSProperties = {textAlign:'left', padding:'8px', borderBottom:'2px solid #eee', fontSize:12, color:'#555'};
const td: React.CSSProperties = {padding:'8px', fontSize:13};
