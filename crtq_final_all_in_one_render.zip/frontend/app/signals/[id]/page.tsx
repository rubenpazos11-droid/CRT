"use client";
import React, { useEffect, useState } from 'react';
const API = process.env.NEXT_PUBLIC_CRTQ_API || 'http://localhost:8000';
export default function SignalDetail({ params }: any){
  const id = params.id;
  const [auth,setAuth] = useState<string>('');
  const [ingest,setIngest] = useState<string>('');
  const [data,setData] = useState<any>(null);
  const [status,setStatus] = useState<string>('tp');
  const [outcome,setOutcome] = useState<string>('1.5');
  const [price,setPrice] = useState<string>('');
  const [report,setReport] = useState<string>('');
  const [msg,setMsg] = useState<string>('');
  async function load(){
    if(!auth){ alert('Introduce X-Auth-Token'); return; }
    const r = await fetch(`${API}/signals/${id}`, { headers: { 'X-Auth-Token': auth } });
    if(!r.ok){ setMsg('Error cargando señal'); return; }
    const j = await r.json(); setData(j);
  }
  async function submit(){
    if(!ingest){ alert('Introduce X-Ingest-Key'); return; }
    const payload:any = { id: Number(id), status };
    if(outcome) payload.outcome = Number(outcome);
    if(price)   payload.price = Number(price);
    if(report)  payload.report_url = report;
    const r = await fetch(`${API}/signals/update`, {
      method: 'POST', headers: { 'Content-Type':'application/json', 'X-Ingest-Key': ingest }, body: JSON.stringify(payload)
    });
    const j = await r.json();
    if(r.ok){ setMsg('Actualizado'); await load(); } else { setMsg(j?.detail || 'Error'); }
  }
  return (
    <main style={{padding:24}}>
      <h1 style={{fontSize:22,fontWeight:700}}>Señal #{id}</h1>
      <div style={{display:'flex', gap:8, alignItems:'center'}}>
        <input placeholder='X-Auth-Token' value={auth} onChange={e=>setAuth(e.target.value)} style={input} />
        <button onClick={load} style={btn}>Cargar</button>
      </div>
      {data && (
        <section style={{marginTop:16, border:'1px solid #eee', borderRadius:12, padding:12}}>
          <div><b>Par:</b> {data.pair} — <b>Fecha:</b> {new Date(data.ts).toLocaleString()}</div>
          <div><b>Prob:</b> {typeof data.prob === 'number' ? data.prob.toFixed(2) : ''} — <b>Ready:</b> {data.readiness} — <b>Precio:</b> {data.price}</div>
          <div><b>Estado:</b> {data.status} — <b>Outcome:</b> {typeof data.outcome==='number' ? data.outcome.toFixed(2) : ''}</div>
          {data.report_url && <div><a href={data.report_url} target='_blank'>Ver reporte</a></div>}
        </section>
      )}
      <section style={{marginTop:16, border:'1px solid #eee', borderRadius:12, padding:12}}>
        <div style={{fontWeight:700, marginBottom:8}}>Cerrar señal</div>
        <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))', gap:8}}>
          <label>Estado<select value={status} onChange={e=>setStatus(e.target.value)} style={input}><option value='tp'>TP</option><option value='sl'>SL</option><option value='closed'>Cerrada</option></select></label>
          <label>Outcome (R)<input value={outcome} onChange={e=>setOutcome(e.target.value)} placeholder='1.5' style={input} /></label>
          <label>Precio salida (opcional)<input value={price} onChange={e=>setPrice(e.target.value)} placeholder='1.0798' style={input} /></label>
          <label>Reporte URL (opcional)<input value={report} onChange={e=>setReport(e.target.value)} placeholder='https://...' style={input} /></label>
        </div>
        <div style={{display:'flex', gap:8, alignItems:'center', marginTop:8}}>
          <input placeholder='X-Ingest-Key' value={ingest} onChange={e=>setIngest(e.target.value)} style={input} />
          <button onClick={submit} style={btn}>Guardar</button>
          <div style={{fontSize:12, color:'#555'}}>{msg}</div>
        </div>
      </section>
    </main>
  );
}
const btn: React.CSSProperties = {padding:'8px 12px', borderRadius:8, background:'#000', color:'#fff'};
const input: React.CSSProperties = {padding:8, border:'1px solid #ddd', borderRadius:8, width:'100%'};
