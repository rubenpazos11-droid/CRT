export default function Home(){ return (<main style={{padding:24}}><h1 style={{fontSize:24,fontWeight:700}}>CRT‑Q Panel</h1><p>Ir a <a href="/signals">Historial & Ranking</a></p></main>); }
