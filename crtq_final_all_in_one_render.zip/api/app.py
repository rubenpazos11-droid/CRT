import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers.signals import router as signals_router
from routers.alerts import router as alerts_router

app = FastAPI(title='CRT-Q — API')
app.add_middleware(CORSMiddleware, allow_origins=os.getenv('CRTQ_CORS','*').split(','), allow_credentials=True, allow_methods=['*'], allow_headers=['*'])
@app.get('/health')
def health(): return {'status':'ok'}
app.include_router(signals_router)
app.include_router(alerts_router)
