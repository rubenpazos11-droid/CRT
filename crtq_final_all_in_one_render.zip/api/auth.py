from fastapi import Header, HTTPException
class UserCtx: pass
def require_reader(x_auth_token: str | None = Header(default=None)):
    if not x_auth_token:
        raise HTTPException(401, 'Missing X-Auth-Token')
    return UserCtx()
def require_writer(x_ingest_key: str | None = Header(default=None)):
    import os
    if not x_ingest_key or x_ingest_key != os.getenv('INGEST_SHARED_KEY',''):
        raise HTTPException(401, 'Invalid or missing X-Ingest-Key')
    return UserCtx()
