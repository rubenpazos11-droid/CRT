from fastapi import APIRouter, Query, Depends, Body, HTTPException, Response
from typing import Optional
import asyncpg, os
import pandas as pd
from auth import require_reader, require_writer

DATABASE_URL = os.getenv('DATABASE_URL')
router = APIRouter(prefix='/signals', tags=['signals'])

async def get_conn():
    if not DATABASE_URL:
        raise RuntimeError('DATABASE_URL no configurada')
    return await asyncpg.connect(DATABASE_URL)

@router.get('')
async def list_signals(pair: Optional[str] = None, date_from: Optional[str] = None, date_to: Optional[str] = None,
                      min_prob: float = 0.0, min_readiness: float = 0.0, user=Depends(require_reader)):
    q = """SELECT id,pair,ts,prob,readiness,price,outcome,status,report_url,context,macro_snapshot
           FROM signals WHERE 1=1"""; args = []
    if pair:       q += f" AND pair = ${len(args)+1}"; args.append(pair)
    if date_from:  q += f" AND ts >= ${len(args)+1}"; args.append(date_from)
    if date_to:    q += f" AND ts <  ${len(args)+1}"; args.append(date_to)
    if min_prob:   q += f" AND prob >= ${len(args)+1}"; args.append(min_prob)
    if min_readiness: q += f" AND readiness >= ${len(args)+1}"; args.append(min_readiness)
    q += ' ORDER BY ts DESC LIMIT 2000'
    conn = await get_conn(); rows = await conn.fetch(q, *args); await conn.close()
    def norm(r):
        return {
            'id': r['id'], 'pair': r['pair'], 'ts': r['ts'].isoformat(),
            'prob': float(r['prob']) if r['prob'] is not None else None,
            'readiness': float(r['readiness']) if r['readiness'] is not None else None,
            'price': float(r['price']) if r['price'] is not None else None,
            'outcome': float(r['outcome']) if r['outcome'] is not None else None,
            'status': r['status'], 'report_url': r['report_url'],
            'context': r['context'], 'macro_snapshot': r['macro_snapshot'],
        }
    return {'items': [norm(x) for x in rows]}

@router.get('/{sid}')
async def get_signal(sid: int, user=Depends(require_reader)):
    conn = await get_conn()
    r = await conn.fetchrow('SELECT id,pair,ts,prob,readiness,price,outcome,status,report_url,context,macro_snapshot FROM signals WHERE id=$1', sid)
    await conn.close()
    if not r:
        raise HTTPException(404, 'No existe')
    return {
        'id': r['id'], 'pair': r['pair'], 'ts': r['ts'].isoformat(),
        'prob': float(r['prob']) if r['prob'] is not None else None,
        'readiness': float(r['readiness']) if r['readiness'] is not None else None,
        'price': float(r['price']) if r['price'] is not None else None,
        'outcome': float(r['outcome']) if r['outcome'] is not None else None,
        'status': r['status'], 'report_url': r['report_url'],
        'context': r['context'], 'macro_snapshot': r['macro_snapshot'],
    }

@router.get('/export')
async def export_csv(user=Depends(require_reader)):
    conn = await get_conn()
    rows = await conn.fetch('SELECT id,pair,ts,prob,readiness,price,outcome,status,report_url FROM signals ORDER BY ts DESC')
    await conn.close()
    df = pd.DataFrame([dict(r) for r in rows])
    csv_bytes = df.to_csv(index=False).encode('utf-8')
    return Response(content=csv_bytes, media_type='text/csv', headers={'Content-Disposition':'attachment; filename=signals_export.csv'})

@router.get('/ranking')
async def ranking(user=Depends(require_reader)):
    conn = await get_conn(); rows = await conn.fetch('SELECT * FROM v_pair_performance'); await conn.close()
    return {'pairs':[{'pair': r['pair'], 'trades': r['trades'], 'pnl_r': float(r['pnl_r'] or 0), 'win_rate': float(r['win_rate'] or 0), 'med_outcome': float(r['med_outcome'] or 0), 'avg_r': float(r['avg_r'] or 0)} for r in rows]}

@router.get('/equity')
async def pair_equity(pairs: Optional[str]=Query(None), user=Depends(require_reader)):
    filt = [p.strip().upper() for p in (pairs or '').split(',') if p.strip()]
    conn = await get_conn()
    if filt:
        rows = await conn.fetch('SELECT pair,d,cum_r FROM v_pair_equity WHERE pair = ANY($1::text[])', filt)
    else:
        rows = await conn.fetch('SELECT pair,d,cum_r FROM v_pair_equity')
    await conn.close()
    out = {}
    for r in rows:
        out.setdefault(r['pair'], []).append({'d': r['d'].isoformat(), 'cum_r': float(r['cum_r'])})
    return {'equities': out}

@router.post('/save')
async def save_signal(payload: dict = Body(...), user=Depends(require_writer)):
    import datetime as dt
    pair = payload.get('pair'); prob = payload.get('prob'); readiness = payload.get('readiness'); price = payload.get('price')
    outcome = payload.get('outcome'); status = payload.get('status'); report_url = payload.get('report_url')
    context = payload.get('context'); macro_snapshot = payload.get('macro_snapshot'); ts = payload.get('ts')
    if not pair: raise HTTPException(400, 'pair es obligatorio')
    if ts is None: ts = dt.datetime.utcnow().isoformat()
    conn = await get_conn()
    row = await conn.fetchrow(
        'INSERT INTO signals (pair, ts, prob, readiness, price, outcome, status, report_url, context, macro_snapshot) '
        'VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id',
        pair, ts, prob, readiness, price, outcome, status, report_url, context, macro_snapshot
    )
    await conn.close()
    return {'ok': True, 'id': row['id']}

@router.post('/update')
async def update_signal(payload: dict = Body(...), user=Depends(require_writer)):
    sid = payload.get('id')
    if not sid: raise HTTPException(400, 'id es obligatorio')
    fields = []; values = []
    for k in ['status','outcome','price','report_url']:
        if k in payload and payload[k] is not None:
            fields.append(f"{k} = ${len(values)+1}"); values.append(payload[k])
    if not fields: raise HTTPException(400, 'Nada que actualizar')
    q = f"UPDATE signals SET {', '.join(fields)} WHERE id = ${len(values)+1} RETURNING id,status,outcome,price,report_url"
    values.append(sid)
    conn = await get_conn(); row = await conn.fetchrow(q, *values); await conn.close()
    if not row: raise HTTPException(404, 'Signal no encontrada')
    return {'ok': True, 'signal': dict(row)}
