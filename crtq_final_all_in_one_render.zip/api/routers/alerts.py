from fastapi import APIRouter, Body, HTTPException
import os, httpx

router = APIRouter(prefix='/alerts', tags=['alerts'])
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID')

async def send_telegram(text: str) -> dict:
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        raise HTTPException(400, 'Telegram no configurado (falta TELEGRAM_BOT_TOKEN o TELEGRAM_CHAT_ID).')
    url = f'https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage'
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.post(url, json={'chat_id': TELEGRAM_CHAT_ID, 'text': text})
        return r.json()

@router.post('/signal')
async def alert_signal(payload: dict = Body(...)):
    text = payload.get('text') or 'CRT-Q: Alerta'
    res = await send_telegram(text)
    return {'ok': True, 'telegram': res}
